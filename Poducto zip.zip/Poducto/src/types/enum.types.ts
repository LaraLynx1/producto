export enum Coleccion {
	'PRODUCTOS' = 'Productos',
}
