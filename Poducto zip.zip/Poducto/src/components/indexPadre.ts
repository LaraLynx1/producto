export { default as toFollow } from '../components/mainPage/toFollow/tofollow';
export { default as cardFollow } from '../components/mainPage/cardFollow/cardfollow';
export { default as CrearPublicacion } from '../components/mainPage/publication/publicacion';
export { default as publicWrapper } from '../components/mainPage/publicwrapper/publicwrapper';
export { default as CrearOpinion } from '../components/mainPage/shareopinion/shareopinion';
export { default as wrapperOpinion } from '../components/mainPage/opinionwrapper/opinionwrapper';
export { default as cardInicio } from '../components/mainPage/sidebar/sidebar';
export { default as cardStories } from '../components/mainPage/cardStories/cardStories';
export { default as storyCard } from '../components/mainPage/stories/stories';
export { default as SignUpComponent } from '../components/SignupPage/Signup';

export { default as PintarProducto } from '../components/pintarProducto/pintarProducto';
export { default as ModificarProducto } from '../components/modificarProducto/modificarProducto';
