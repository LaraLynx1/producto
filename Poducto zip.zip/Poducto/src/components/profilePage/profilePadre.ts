export { default as Crearfoto } from './fotosmias';
export { default as fotowrapper } from './fotoswrapper';
