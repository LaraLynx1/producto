export { default as dashboard } from './dashboard';
export { default as Perfil } from './perfil';
export { default as LOGIN } from './login';
export { default as SIGNUP } from './signup';