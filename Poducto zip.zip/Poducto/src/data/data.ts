export const whotofollow = [
	{
		image: 'https://e00-telva.uecdn.es/assets/multimedia/imagenes/2024/02/18/17082291054247.jpg',
		name: 'Iam The Real Coquette',
		arroba: '@IAmTheRealCoquette',
	},
	{
		image: 'https://eldiario.com/wp-content/uploads/2024/01/Coquette-1-.jpg',
		name: 'Charlie morningstar',
		arroba: '@charliemorningstar',
	},
	{
		image:
			'https://www.semana.com/resizer/r0OI-UL1npAMnFaFqySPh7RqzLU=/arc-anglerfish-arc2-prod-semana/public/MDNDZ5QVPFDUFMXQFO54CL7PVA.jpg',
		name: 'How To bows',
		arroba: '@howtobows',
	},
	{
		image:
			'https://www.semana.com/resizer/r0OI-UL1npAMnFaFqySPh7RqzLU=/arc-anglerfish-arc2-prod-semana/public/MDNDZ5QVPFDUFMXQFO54CL7PVA.jpg',
		name: 'How To bows',
		arroba: '@howtobows',
	},
	{
		image:
			'https://www.semana.com/resizer/r0OI-UL1npAMnFaFqySPh7RqzLU=/arc-anglerfish-arc2-prod-semana/public/MDNDZ5QVPFDUFMXQFO54CL7PVA.jpg',
		name: 'How To bows',
		arroba: '@howtobows',
	},
	{
		image:
			'https://www.semana.com/resizer/r0OI-UL1npAMnFaFqySPh7RqzLU=/arc-anglerfish-arc2-prod-semana/public/MDNDZ5QVPFDUFMXQFO54CL7PVA.jpg',
		name: 'How To bows',
		arroba: '@howtobows',
	},
];

export const publics = [
	{
		user: 'LadyNoir',
		userpfp:
			'https://www.semana.com/resizer/r0OI-UL1npAMnFaFqySPh7RqzLU=/arc-anglerfish-arc2-prod-semana/public/MDNDZ5QVPFDUFMXQFO54CL7PVA.jpg',
		image: 'https://i.pinimg.com/564x/2a/b9/2d/2ab92d8d2861b73ce4af0f7f9c341ada.jpg',
		likes: '2040',
	},
	{
		user: 'AventurineSimp',
		userpfp:
			'https://www.semana.com/resizer/r0OI-UL1npAMnFaFqySPh7RqzLU=/arc-anglerfish-arc2-prod-semana/public/MDNDZ5QVPFDUFMXQFO54CL7PVA.jpg',
		image: 'https://i.pinimg.com/736x/88/69/e1/8869e10a10e7e658f082d4f1a49aa2c5.jpg',
		likes: '488',
	},
];
export const useropinion = [
	{
		userpfp:
			'https://www.semana.com/resizer/r0OI-UL1npAMnFaFqySPh7RqzLU=/arc-anglerfish-arc2-prod-semana/public/MDNDZ5QVPFDUFMXQFO54CL7PVA.jpg',
	},
];

export const fotosperfil = [
	{
		image: 'https://www.shutterstock.com/image-vector/draw-seamless-pattern-red-cherry-600nw-2412112351.jpg',
	},
	{
		image: 'https://i.ytimg.com/vi/BpL_Xf7Q5Ug/maxresdefault.jpg',
	},
	{
		image:
			'https://garden.spoonflower.com/c/16489465/p/f/m/uzyRE3hAb8N_lzKKI7PnneYTTtozInVWrjmRYKkXb0WcRHIrUXDW/12%22%20%20Pink%20Bow%20Print%20-%20Coquette%20Aesthetic%20Ribbon%20Bow%20-%20Girls%20Room%20Decor.jpg',
	},
	{
		image:
			'https://garden.spoonflower.com/c/15318157/p/f/m/1LnuXKYBlwmrakVRjfShkqpcy2ZdhvzxzzQYBEZT9-Ekfrw3Pc4H1d8/Brown%20vintage%20ribbon%20bows%20on%20soft%20blush%20pink%2FMEDIUM.jpg',
	},
	{
		image: 'https://t4.ftcdn.net/jpg/06/81/50/51/360_F_681505176_MjOXAmjMqHtphlRmbwc6HFdSdY9YKpzX.jpg',
	},
	{
		image:
			'https://www.elsoldehermosillo.com.mx/doble-via/xekztl-moda-coquette-lolita/ALTERNATES/LANDSCAPE_1140/Moda%20Coquette%20Lolita',
	},
];

export const stories = [
	{
		image: 'https://prod.api.assets.riotgames.com/public/v1/asset/lol/14.5.1/CHAMPION_SKIN/51039/ICON',
		name: 'Caitlyn',
	},
	{
		image: 'https://prod.api.assets.riotgames.com/public/v1/asset/lol/14.6.1/CHAMPION_SKIN/235046/ICON',
		name: 'Senna',
	},
	{
		image: 'https://prod.api.assets.riotgames.com/public/v1/asset/lol/14.6.1/CHAMPION_SKIN/145040/ICON',
		name: 'Kaisa',
	},
	{
		image:
			'https://preview.redd.it/lovestruck-lux-port-mission-v0-2vwnvbfsnfac1.jpeg?auto=webp&s=161092691f8478293c7b88da9f08ac2848f167e6',
		name: 'Lux',
	},
	{
		image: 'https://i1.sndcdn.com/artworks-DzKaeKvz64CglhKq-O7Jy1w-t500x500.jpg',
		name: 'Seraphine',
	},
	{
		image: 'https://prod.api.assets.riotgames.com/public/v1/asset/lol/14.5.1/CHAMPION_SKIN/134044/ICON',
		name: 'Syndra',
	},
	{
		image: 'https://prod.api.assets.riotgames.com/public/v1/asset/lol/14.5.1/CHAMPION_SKIN/134044/ICON',
		name: 'Syndra',
	},
	{
		image: 'https://prod.api.assets.riotgames.com/public/v1/asset/lol/14.5.1/CHAMPION_SKIN/134044/ICON',
		name: 'Syndra',
	},
	{
		image: 'https://prod.api.assets.riotgames.com/public/v1/asset/lol/14.5.1/CHAMPION_SKIN/134044/ICON',
		name: 'Syndra',
	},
];
